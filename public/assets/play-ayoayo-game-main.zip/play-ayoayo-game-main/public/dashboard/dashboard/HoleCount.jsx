function HoleCount({ children }) {
  return <div className="ugo-hole-count">{children}</div>;
}

export default HoleCount;
