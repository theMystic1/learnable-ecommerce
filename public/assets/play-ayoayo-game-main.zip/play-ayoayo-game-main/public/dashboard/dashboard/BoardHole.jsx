function BoardHole({ children }) {
  return <div className="ugo-hole">{children}</div>;
}

export default BoardHole;
