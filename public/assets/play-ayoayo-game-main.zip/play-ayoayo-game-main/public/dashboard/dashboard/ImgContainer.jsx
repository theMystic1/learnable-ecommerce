function ImgContainer({ children }) {
  return <div className="ugo-img-div">{children}</div>;
}

export default ImgContainer;
