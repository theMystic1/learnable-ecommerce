function TimerProfile({ children }) {
  return <div className="ugo-timer-profile">{children}</div>;
}

export default TimerProfile;
