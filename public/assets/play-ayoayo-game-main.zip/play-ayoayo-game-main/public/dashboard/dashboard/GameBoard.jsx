function GameBoard({ children }) {
  return <div className="ugo-board">{children}</div>;
}

export default GameBoard;
