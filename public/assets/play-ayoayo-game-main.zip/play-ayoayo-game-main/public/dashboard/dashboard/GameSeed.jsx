function GameSeed() {
  return <div className="ugo-seed"></div>;
}

export default GameSeed;
