function Count({ children }) {
  return <p className="ugo-count">{children}</p>;
}

export default Count;
