function ScoreCard({ children }) {
  return <div className="ugo-score-card">{children}</div>;
}

export default ScoreCard;
