import React from 'react'
import Avatar from './Avatar'

function AvatarList() {
  return (
    <div>
      <Avatar />
    </div>
  )
}

export default AvatarList