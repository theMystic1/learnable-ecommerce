export const goldMedal = "/assets/gold.png";
export const silverMedal = "/assets/silver.png";
export const bronzeMedal = "/assets/bronze.png";
export const coin = "/assets/coin.svg";
export const backButton = "/assets/back-button.svg";
export const leaderboardStar = "/assets/leaderboard-star.svg";
