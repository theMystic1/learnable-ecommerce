function Nav() {
  return <div>navigation</div>;
}

export default Nav;
