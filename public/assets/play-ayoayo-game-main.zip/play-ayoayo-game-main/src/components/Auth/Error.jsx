function Error({ children }) {
  return <p className="error">{children}</p>;
}

export default Error;
