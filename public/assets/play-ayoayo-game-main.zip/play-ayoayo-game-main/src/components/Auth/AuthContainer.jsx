function AuthContainer({ children }) {
  return <div className="auth-cont">{children}</div>;
}

export default AuthContainer;
