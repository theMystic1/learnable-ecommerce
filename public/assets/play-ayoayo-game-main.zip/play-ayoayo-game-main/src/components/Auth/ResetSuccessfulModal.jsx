function ResetSuccessfulModal() {
  return <div className="reset-modal"></div>;
}

export default ResetSuccessfulModal;
