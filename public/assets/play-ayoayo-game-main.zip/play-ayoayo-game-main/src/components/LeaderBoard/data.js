export const data = [
  {
    id: 1,
    name: "Edozie Eze",
    coins: 26347,
    rank: 1,
    stars: 5,
    avatar: "/assets/avatar_1.png",
  },
  {
    id: 2,
    name: "Chukwu Vincent",
    coins: 4036,
    rank: 2,
    stars: 4,
    avatar: "/assets/avatar_2.png",
  },
  {
    id: 3,
    name: "Shedrach",
    coins: 2983,
    rank: 3,
    stars: 3,
    avatar: "/assets/avatar_3.png",
  },
  {
    id: 4,
    name: "Victor Ani",
    coins: 507,
    rank: 4,
    stars: 2,
    avatar: "/assets/avatar_4.png",
  },
];
