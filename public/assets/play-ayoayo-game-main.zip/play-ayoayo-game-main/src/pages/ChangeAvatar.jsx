import AvatarList from "../components/Avatar/AvatarList";


function ChangeAvatar() {
  return (
  <div>
<AvatarList />
  </div>
  )
}

export default ChangeAvatar;
