import SettingWrapper from "../components/settings/SettingWrapper";

function Settings() {
  return <SettingWrapper />;
}

export default Settings;
