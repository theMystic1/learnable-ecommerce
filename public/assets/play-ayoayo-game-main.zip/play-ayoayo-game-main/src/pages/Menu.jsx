import MenuWrapper from "../components/Menu/MenuWrapper";

function Menu() {
  return (
    <div className="menu-container">
      <MenuWrapper />
    </div>
  );
}

export default Menu;
