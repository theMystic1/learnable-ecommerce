import "../components/Auth/Auth.css";
import NicknameItem from "../components/Auth/NicknameItem";

function Nickname() {
  return (
    <div className="howto">
      <NicknameItem />
    </div>
  );
}

export default Nickname;
