import VerificationItem from "../components/Auth/VerificationItem";

function Verification() {
  return (
    <div className="howto">
      <VerificationItem />
    </div>
  );
}

export default Verification;
