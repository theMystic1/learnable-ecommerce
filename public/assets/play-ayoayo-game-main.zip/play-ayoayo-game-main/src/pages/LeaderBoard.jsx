import Leaderboard from "../components/LeaderBoard/Leaderboard";

function LeaderBoard() {
  return <Leaderboard />;
}

export default LeaderBoard;
