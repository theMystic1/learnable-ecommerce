import ResetPasswordItem from "../components/Auth/ResetPasswordItem";

function PasswordReset() {
  return (
    <div className="howto">
      <ResetPasswordItem />
    </div>
  );
}

export default PasswordReset;
