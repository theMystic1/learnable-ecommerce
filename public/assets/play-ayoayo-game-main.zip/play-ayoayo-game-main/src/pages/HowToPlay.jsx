import HowtoPlay from "../components/HowToPlay/HowtoPlay";
function HowToPlay() {
  return (
    <div className="howto">
      <HowtoPlay />;
    </div>
  );
}

export default HowToPlay;
