import LandingPageWrapper from "../components/Landingpage/LandingPageWrapper";
import Footer from "../components/Landingpage/Footer";

function LandingPage() {
  return (
    <div>
      {/* <Nav /> */}
      <LandingPageWrapper />
      <Footer />
    </div>
  );
}
export default LandingPage;
