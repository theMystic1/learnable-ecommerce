import GameLevelWrapper from "../components/GameLevel/GameLevelWrapper";


function GameLevel() {

  return (
  <div>
  <GameLevelWrapper />
    </div>
  )
}

export default GameLevel;
