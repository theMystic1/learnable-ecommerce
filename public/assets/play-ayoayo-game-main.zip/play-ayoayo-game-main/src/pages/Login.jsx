import LoginItem from "../components/Auth/LoginItem";
import "../components/Auth/Auth.css";

function Login() {
  return (
    <div className="howto">
      <LoginItem />
    </div>
  );
}

export default Login;
