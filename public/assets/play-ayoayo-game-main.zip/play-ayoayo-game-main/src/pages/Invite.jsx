function Invite() {
  return <div style={{ padding: "40px", color: "#ffff" }}>coming soon....</div>;
}

export default Invite;
