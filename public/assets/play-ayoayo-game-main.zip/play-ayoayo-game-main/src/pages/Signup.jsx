import "../components/Auth/Auth.css";
import SignupItem from "../components/Auth/SignupItem";

function Signup() {
  return (
    <div className="howto">
      <SignupItem />
    </div>
  );
}

export default Signup;
