import AboutWrapper from "../components/About/AboutWrapper";

function About() {
  return(
    <div>
<AboutWrapper />
    </div>
  )
}

export default About
